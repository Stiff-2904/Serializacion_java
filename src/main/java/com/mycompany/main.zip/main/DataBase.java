package com.mycompany.main;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class DataBase {

    public final String FILE_NAME_EMPLOYEES = "empleados.ser";

    void menu() {
        int option;

        do {
            option = Integer.parseInt(JOptionPane.showInputDialog("1.Agregar un empleado y departamento.\n2.Buscar un empleado/departamento.\n3.Eliminar un empleado/departamento\n0.Salir."));
            System.out.println(option);
            switch (option) {
                case 1:
                    fillDates();
                    break;

                case 2:
                    search();
                    break;

                case 3:
                    deletes();
                    break;

                case 0:
                    JOptionPane.showMessageDialog(null, "Estas saliendo del programa\nVuelve pronto\nTe extrañaremos");
                    break;

                default:

                    JOptionPane.showMessageDialog(null, "Opción no válida");
                    break;
            }
        } while (option != 0);

    }

    void fillDates() {

        String nameEmployee = JOptionPane.showInputDialog(null, "Ingrese el nombre del empleado");

        String lastNameEmployee = JOptionPane.showInputDialog(null, "Ingrese el apellido del empleado");

        int IDEmployee = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el número de cédula del empleado"));

        int ageEmployee = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la edad del empleado"));

        Employee newEmployee = new Employee(nameEmployee, lastNameEmployee, IDEmployee, ageEmployee);

        //  String departmentName = JOptionPane.showInputDialog(null, "Ingrese el nombre del departamento");
        // String departmentUbication = JOptionPane.showInputDialog(null, "Ingrese la ubicación del departamento");
        //Department newDepartment = new Department(departmentName, departmentUbication, newEmployee);
        addEmployee2(newEmployee);

        //addDepartment(newDepartment);
    }

    void addEmployee(Employee newEmployee) {

        try {
            File file = new File(FILE_NAME_EMPLOYEES);
            boolean fileExists = file.exists();

            FileOutputStream fileOut = new FileOutputStream(file, true);

            if (!fileExists) {
                file.createNewFile();
            }

            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);

            objOut.writeObject(newEmployee);

            objOut.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void addEmployee2(Employee newEmployee) {

        try {
            File file = new File(FILE_NAME_EMPLOYEES);
            boolean fileExists = file.exists();

            FileOutputStream fileOut = new FileOutputStream(file, true);

            ArrayList<Employee> employees = new ArrayList<Employee>();

            if (!fileExists) {
                file.createNewFile();
            } else {
                employees = readEmployees();
                employees.forEach(employee -> {
                    System.out.println(employee.getName());
                });
            }

            employees.add(newEmployee);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);

            objOut.writeObject(employees);

            objOut.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Employee> readEmployees() {
        try (FileInputStream fis = new FileInputStream(FILE_NAME_EMPLOYEES); ObjectInputStream ois = new ObjectInputStream(fis)) {

            return (ArrayList<Employee>) ois.readObject();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (EOFException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;

        }
    }

//    void addDepartment(Department newDepartment) {
//        String fileName = "departament.ser";
//
//        try {
//            File file = new File(fileName);
//            boolean fileExists = file.exists();
//
//            FileOutputStream fileOut = new FileOutputStream(file, true);
//
//            if (!fileExists) {
//                file.createNewFile();
//            }
//
//            ObjectOutputStream objOut;
//
//            if (fileExists) {
//                objOut = new ObjectOutputStream(fileOut);
//            } else {
//                objOut = new MiObjectOutputStream(fileOut);
//            }
//
//            objOut.writeObject(newDepartment);
//
//            objOut.close();
//            fileOut.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
    void search() {
        int option = Integer.parseInt(JOptionPane.showInputDialog(null, "1.Buscar empleado\n2.Buscar departamento"));

        if (option == 1) {
            searchEmployee();
            return;
        }
        if (option == 2) {
            searchDepartment();
            return;
        }
        JOptionPane.showMessageDialog(null, "Numero incorrecto.");
    }

    void searchEmployee() {

        int option = Integer.parseInt(JOptionPane.showInputDialog("1.Buscarlo por medio el nombre\n2.Buscalo por medio de la cedula"));

        if (option == 1) {
            String name = JOptionPane.showInputDialog("Ingrese el nombre del empleado");

            try (FileInputStream fis = new FileInputStream(FILE_NAME_EMPLOYEES); ObjectInputStream ois = new ObjectInputStream(fis)) {

                Employee auxEmployee = (Employee) ois.readObject();
                //Department auxDeparment = (Department) ois.readObject();
                if (auxEmployee.getName().equals(name)) { //&& auxDeparment.getEmployee().equals(auxEmployee)
                    JOptionPane.showMessageDialog(null, auxEmployee.getName());
                }

            } catch (ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Usuario no encontrado");
            } catch (EOFException e) {
                JOptionPane.showMessageDialog(null, "Fin del archivo alcanzado");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error de lectura del archivo");
            }
            return;
        }
        if (option == 2) {
            int ID = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de cedula del empleado"));

            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\empleados.ser"))) {

                while (true) {
                    Employee auxEmployee = (Employee) ois.readObject();
                    Department auxDeparment = (Department) ois.readObject();
                    if (auxEmployee.getName().equals(ID) && auxDeparment.getEmployee().equals(auxEmployee)) {
                        JOptionPane.showMessageDialog(null, auxEmployee.toString());
                    }
                }
            } catch (ClassNotFoundException e) {
                e.getException();
                JOptionPane.showMessageDialog(null, "Usuario no encontrado");
            } catch (EOFException e) {
                e.getCause();
            } catch (IOException e) {
                e.getCause();
            }
            return;
        }
        JOptionPane.showMessageDialog(null, "Numero incorrecto.");
        System.out.println("ESTEEE1");
    }

    void searchDepartment() {
        String nameDepartment = JOptionPane.showInputDialog(null, "Ingrese el nombre del deparamento.");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("D:\\empleados.txt"))) {

            while (true) {
                Department auxDeparment = (Department) ois.readObject();
                if (true) {

                }
                //Employee auxEmployee = (Employee) ois.readObject();

            }
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Usuario no encontrado");
        } catch (EOFException e) {
        } catch (IOException e) {
        }

    }

    void deletes() {
        int option = Integer.parseInt(JOptionPane.showInputDialog(null, "1.Eliminar empleado\n2.Eliminar departamento"));

        if (option == 1) {
            deleteEmployee();
            return;
        }
        if (option == 2) {
            deleteDepartment();
            return;

        }
        JOptionPane.showMessageDialog(null, "Numero incorrecto.");
    }

    void deleteEmployee() {
        //fxghchfddddgdfgdfgdfgdfgdfgdf

    }

    void deleteDepartment() {
        //fxghchfddddgdfgdfgdfgdfgdfgdf

    }

}
